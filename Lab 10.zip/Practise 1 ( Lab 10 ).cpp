
#include <iostream>

using namespace std;

class Rectangle{
	public:
		double get_perimeter (double height, double width){
			return (2*height + 2*width);
		}
		double get_area (double height, double width){
			return (height*width);
		}
		void resize (double factor){
			cout << " New width: " << width*factor << endl;
			cout << " New height: "<< height*factor << endl;
		}
		Rectangle (double w, double h){
			width = w;
			height= h;
		}
		
	private:
		double width;
		double height;
};

int main()
{

	// Name & Matric No.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	// Lab & Practise No.
	cout << " Lab 10 (Practise 1) \n" << endl;
	
	double width, height, factor;
	
	cout << " Please enter width: ";
	cin  >> width;
	
	cout << " Please enter height: ";
	cin  >> height;
	
	cout << " Please enter factor: ";
	cin  >> factor;
	
	Rectangle rect1(width, height);
	
	cout << " The area of the rectangle is: " << 
	rect1.get_area(height, width) << " cm square " << endl;
	
	cout << " The perimeter of the rectangle is: " << 
	rect1.get_perimeter(height, width) << " cm " << endl;
	
	rect1.resize(factor);
	
	return 0;	
}


/*
#include <iostream>

using namespace std;

	class Rectangle 
	{
		public:
				
				double perimeter (double width, double height)
				{
					return (2*width + 2*height);
				}
				
				double area (double width, double height)
				{
					return (width*height);
				}
				
				void resize (double factor)
				{
					cout << " New width  : " << width*factor << endl;
					cout << " New height : " << height*factor << endl;
				}
				
				Rectangle (double w, double h)
				{
					w = width;
					h = height;
				}
				
		private:
				double width;
				double height;
		
	};

int main()
{
	double width, height, factor;
	
	cout << " Enter width  : ";
	cin  >> width;
	
	cout << " Enter height : ";
	cin  >> height;
	
	cout << " Enter factor : ";
	cin  >> factor;
	
	Rectangle rect1 (width, height);
	
	cout << " Perimeter of Rectangle : " << rect1.perimeter(width, height) << endl;
	cout << " Area of Rectangle      : " << rect1.area(width, height) << endl;	
	rect1.resize(factor);
}
*/
