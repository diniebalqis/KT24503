#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <string>

using namespace std;
void getData (float* length, float* width, float* discount, float* cost);
void printMeasurement (float length, float width);
double calculateSubTotal(float* carpet_price, float* labor_price, float* discount, float* cost);
double calculateTax(float gst);
double calculateDiscount (float subtotal, float discount);

int main()
{
    const double labor_cost = 2.50;
    const double tax_rate = 5.5 / 100;
    float length, width, discount, cost;

    //name and no.matric and practise, lab
    cout << "Nur Dinie Balqis Binti Abdul Yazid \n" << "BI19110029 \n" << endl;
    cout << "Lab 8 (Practise 3)\n" << endl;
    getData (& length, & width, & discount, & cost);

    //results
    cout << setw(38) << "NDB Sdn. Bhd \n"
         << setw(38) << "80, Jln UMS, \n"
         << setw(45) << "88400, Kota Kinabalu, Sabah \n"
         << "MEASUREMENT" << endl;
    cout << endl;

    printMeasurement (length, width);

    cout << "CHARGES \n"
         << endl;

    //formulas
    float carpet_price = length * width * cost;
    float labor_price = length * width * labor_cost;

    cout << "DESCRIPTION      COST/SQ.FT         CHARGE \n"
         << "-----------      ----------      ------------- \n"
         << "Carpet" << setw(17) << "RM" << fixed << setprecision(2) << cost
         << setw(11) << "RM" << fixed << setprecision(2) << carpet_price << endl;

    cout << "Labor" << setw(18) << "RM" << fixed << setprecision(2) << labor_cost
         << setw(11) << "RM" << fixed << setprecision(2) << labor_price << endl;

    cout << setw(49) << "------------- \n"
         << setw(35) << "SUB TOTAL      :  " << "RM" << fixed << setprecision(2) << calculateSubTotal(& carpet_price, & labor_price , & discount, & cost) << endl;
    cout << setw(49) << "------------- \n"
         << setw(35) << "DISCOUNT(10%)  :  " << "RM" << fixed << setprecision(2) << calculateDiscount (calculateSubTotal(& carpet_price, & labor_price , & discount, & cost), discount) << endl;
    cout << setw(35) << "GST (5.5%)     :  " << "RM" << fixed << setprecision(2) << calculateTax(calculateSubTotal(& carpet_price, & labor_price , & discount, & cost)) << endl;

    //formulas
    float total_price = calculateSubTotal(& carpet_price, & labor_price , & discount, & cost) - calculateDiscount (calculateSubTotal(& carpet_price, & labor_price , & discount, & cost), discount) - calculateTax(calculateSubTotal(& carpet_price, & labor_price , & discount, & cost));

    cout << setw(49) << "------------- \n"
         << setw(35) << "TOTAL          :  " << "RM" << fixed << setprecision(2) << total_price << endl;

    return 0;
}

void getData (float* length, float* width, float* discount, float* cost)
{
    //data input
    cout << "Length of room (feet)          => ";
    cin >> *length;
    cout << "Width of room (feet)           => ";
    cin >> *width;
    cout << "Customer discount (percentage) => ";
    cin >> *discount;
    cout << "Cost per square foot (xxx.xx)  => ";
    cin >> *cost;
    cout << " \n" << " \n" << endl;
}

void printMeasurement (float length, float width)
{
    //results
    cout << "Length" << setw(10) << fixed << setprecision(2) << length << "ft \n"
         << "Width " << setw(10) << fixed << setprecision(2) << width << "ft \n"
         << "Area  " << setw (10) << fixed << setprecision(2) << length*width << "square ft \n"
         << endl;
}

double calculateSubTotal(float* carpet_price, float* labor_price, float* discount, float* cost)
{
    //formulas
    double subtotal = (*carpet_price + *labor_price);
    return subtotal;   //subtotal is return to main function
}

double calculateTax(float subtotal)
{
    //formulas
    const double tax_rate = 5.5 / 100;
    float gst;
    gst = tax_rate * subtotal;
    return gst;   //gst is return to main function
}

double calculateDiscount (float subtotal, float discount)
{
   discount = discount/100 * subtotal;
   return discount;   //discount is return to main function
}
