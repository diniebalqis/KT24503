#include <iostream>
#include <iomanip>

using namespace std;
void swap(float *a, float *b);   // void swap( float* n1, float* n2);


int main()
{
	//name, matric no. & lab practise
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029\n" << endl;
	cout << " Practise 1 (Lab 8) \n" << endl;

	float n1;
	float n2;

	cout << " Enter Number 1 (e.g 2.00): ";
	cin >> n1;

	cout << " Enter Number 2 (e.g 2.00): ";
	cin >> n2;

	cout << "\n" << " After exchanged," << endl;

	swap (&n1,&n2);   // past the address with & symbol
	cout << setprecision (2) << fixed << endl;
	cout << " Number 1 is: " << n1 << endl;
	cout << " Number 2 is: " << n2 << endl;

	return 0;
}

void swap(float *a, float *b)   // void swap( float* n1, float* n2)
{
                   // float temp;
   *a = *a + *b;   // temp = *n1;
   *b = *a - *b;   // *n1  = *n2;
   *a = *a - *b;   // *n2  = temp;
}
