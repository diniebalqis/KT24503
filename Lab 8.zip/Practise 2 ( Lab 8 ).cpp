#include <iostream>
#include <cstdlib>

using namespace std;
void instruct(void);
void dispenser (int amount, int*bill_100, int*bill_50, int*bill_20, int*bill_10);

int main()
{
    int amount, bill_100, bill_50, bill_20, bill_10;

    // name, matric no., lab, practise
    cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
    cout << " Lab 8 (Practise 2) \n" << endl;

	cout << " BALQIS BANK Automatic Teller Machine ATM " << endl;
	do
    {
        cout << " \n Enter withdraw Amount: ";
	    cin  >> amount;

	    if (amount%10 != 0)  //modulus number must be zero
        {
            instruct ();
        }
        else
        {
            dispenser (amount, &bill_100, &bill_50, &bill_20, &bill_10);

            cout   << " Number of 100 bills: " << bill_100 << endl;
            cout   << " Number of 50 bills: " << bill_50 << endl;
            cout   << " Number of 20 bills: " << bill_20 << endl;
            cout   << " Number of 10 bills: " << bill_10 << endl;
            break;
        }
	}
	while (true);

	return 0;
}

void instruct(void)
{
    cout << " \n Invalid Input! \n" ;
    cout << " Please enter a multiple of 10 dollars \n" << endl;
}

void dispenser (int amount, int*bill_100, int*bill_50, int*bill_20, int*bill_10)
{
    int remain;

    *bill_100 = amount/100;
     remain   = amount%100;

    *bill_50  = remain/50;
     remain   = remain%50;

    *bill_20  = remain/20;
     remain   = remain%20;

    *bill_10  = remain/10;
}
