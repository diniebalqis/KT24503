#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <string>

using namespace std;
int main ()

{
	// name and matric no.	
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	
	// practise no. & lab no.
	cout << " Practise 4 (Lab 4) \n" << endl;
	
	// constant variables - part 1
	int num, a, b, c,d;
	
	cout << " Enter a positive four-digit number : ";
	cin >> num;
	
	a = num / 1000;
	num = num % 1000;
	b = num / 100;
	num = num % 100;
	c = num / 10;
	num = num % 10;
	d = num / 1;
	num = num % 1;
	
	cout << "\n" << " I have scrambled your number into two numbers: " << b << a << d << c << " and " << d << c << a << b << endl;
	cout << "\n" << " Now subtract the smaller from the larger, and secretly pick a non-zero digit from the difference." << endl;
	
	// constant variables - part 2
	int num_diff;
	
	cout << "\n" << " Enter the other three digits of the difference : ";
	cin >> num_diff;
	
	// constant variables - part 3
	int e;
	e = 9-(num_diff%9);
	
	cout << "\n" << " The secret digit is " << e << " !";	
	
return 0;
}
