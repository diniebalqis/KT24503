#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>

using namespace std;
int main ()

{
	// name and matric no.	
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	
	// practise no. & lab no.
	cout << " Practise 1 (Lab 4)-for \n" << endl;
	
	// constant variables
	const int y = 2;
	const int x = 10;
	
	// data input & output
	cout << "\n" << setw(11) << "Number" << setw(26) << " Number per squared " << "\n" << setw(12) << "=======" << setw(27) << "==================== \n" << endl; 
	for (int x = 1; x<=10; x++)
		cout << setw(7) << x << setw(21) << pow(x,y) << endl;
		
return 0;
}		
