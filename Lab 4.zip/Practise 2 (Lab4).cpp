#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;
int main()

{
	// name and matric no.	
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	
	// practise no. & lab no.
	cout << " Practise 2 (Lab 4) \n" << endl;
	
	// input & output
	int a, b, c, d; // a-rows, b-number of rows, c-columns, d-number of columns
	cout << " Enter an Integer : ";
	cin >> b;
	
	d=b;
	for (a=1; a<=b; a++){
	for (c=d; c>=1; c--){
	cout << c << ""; 	
	} // bracket second 'for' - colums
	cout << "\n";
	d--; 
	} // bracket first 'for' - rows
		
return 0; 
}

