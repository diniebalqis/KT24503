#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>

using namespace std;
int main ()

{
	// name and matric no.	
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	
	// practise no. & lab no.
	cout << " Practise 1 (Lab 4)-while \n" << endl;
	
	// constant variables
	const int y = 2;
	
	// data input & output
	cout << "\n" << setw(11) << "Number" << setw(26) << " Number per squared " << "\n" << setw(12) << "=======" << setw(27) << "==================== \n" << endl; 
	int x = 1;
	while (x<=10)
	{
		cout << setw(7) << x << setw(21) << pow(x,y) << endl;
		x++;
	} 
		
return 0;
}		
