#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>

using namespace std;
int main ()

{
	// name and matric no.	
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	
	// practise no. & lab no.
	cout << " Practise 3 (Lab 4) \n" << endl;
	
	// constant variables
	int a, mult = 1;
	
	cout << " Enter four positive integer    : ";
	cin >> a;
	
	while (a!=0)
	{
		mult= mult*(a%10);
		a= a/10;
	}
	cout << "\n" << " Multiplication of integer : " << mult << endl;
	
return 0;
}
	
