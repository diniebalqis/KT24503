#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <string>

using namespace std;

int main()
{

	// name and no. matric
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 " << endl;
	
	// no. of lab and practise
	cout << " Practise 4 (Lab3)" << "\n" << "\n" << endl;
	
	//variables declaration
	int car, bus, truck;
	int hour_enter, minute_enter;
	int hour_out, minute_out;
	double hour, total_hour, minute, total_minute, total_time, rate_1, rate_2;
	double charge, penalty, total_charge;

	cout << "Type of vehicle   : " ;
	string vehicle;
	cin >> vehicle;
	if (vehicle == "C" || vehicle == "c") {
		vehicle = "Car";
	}
	else if (vehicle == "B" || vehicle == "b") {
		vehicle = "Bus";
	}
	else if (vehicle == "T" || vehicle == "t") {
		vehicle = "Truck";
	}
	
	cout << "Hour of vehicle entered lot (0 - 24)  :  ";
	cin  >> hour_enter ;
	
	cout << "Minute of vehicle entered lot (0 - 60):  ";
	cin  >> minute_enter;
	
	cout << "Hour of vehicle left lot (0 - 24)     :  ";
	cin  >> hour_out;
	
	cout << "Minute of vehicle left lot (0 - 60)   :  ";
	cin  >> minute_out;
	
	//formula 1
	if (minute_out > minute_enter){
		total_minute = minute_out - minute_enter;
	}
	else if (minute_out < minute_enter){
		total_minute = minute_enter - minute_out;
	}
	else if (minute_out == minute_enter){
		total_minute = 0;
	}
	
	//formula 2
	if (hour_out < hour_enter){
		total_hour = (24 - hour_enter) + hour_out;
	}
	else {
	total_hour = hour_out - hour_enter;
	}
	total_time = total_hour + (total_minute / 60);
	
	//main formula
	if (vehicle == "Car" && total_time <= 3) {
		rate_1 = 1.00;
		charge = rate_1 * total_time;
	}
	else if (vehicle == "Car" && total_time > 3){
		rate_2 = 2.00;
		charge = ((total_time - 3) * rate_2)  + 3;
	}
	
	
	if (vehicle == "Bus" && total_time <= 3) {
		rate_1 = 1.50;
		charge = rate_1 * total_time;
	}
	else if (vehicle == "Bus" && total_time > 3) {
		rate_2 = 2.50;
		charge =((total_time - 3) * rate_2)  + 4.5;
	}
	
	
	if (vehicle == "Truck" && total_time <= 3) {
		rate_1 = 2.00;
		charge = rate_1 * total_time;
	}
	else if (vehicle == "Truck" && total_time > 3){
	
		rate_2 = 3.00;
		charge = ((total_time - 3) * rate_2)  + 6;
    }
    
    //formula 3
	if ((hour_enter + total_time) > 24){
		penalty = 150.00;
	}
	else{
		penalty = 00.00;
	}
	total_charge = charge + penalty;
	
	//0utput program
	cout << endl;
	cout << setw(60) << "******************" << endl; 
	cout << setw(58) << "ABC Sdn. Bhd" << endl;
	cout << setw(60) << "PARKING LOT CHARGE" << endl;
	cout << setw(60) << "******************" << endl;
	cout << endl;
	
	cout << "Type of Vehicle : " << vehicle << endl;
	cout << "TIME-IN : " << setw(42) << hour_enter << setw(3) << ": " << setw(2) << minute_enter << endl;
	cout << "TIME-OUT: " << setw(42) << hour_out   << setw(3) << ": " << setw(2) << minute_out << endl;
	cout << endl;
	cout << endl;
	
	cout << setw(60) << "-----------------" << endl;
	cout << "PARKING TIME:" << setw(39) << total_hour << setw(2) <<":" << setw(3)<< total_minute << endl;
	cout << setw(60) << "-----------------" << endl;
	cout << "PARKING FARE:" << setw(35) << "RM" << setw(9) << fixed << setprecision(2) << charge << endl;
	cout << "PENALTY FARE:" << setw(35) << "RM" << setw(9) << penalty << endl;
	cout << setw(60) << "-----------------" << endl;
	cout << "TOTAL CHARGE: " << setw(34) << "RM"<< setw(9) << fixed << setprecision(2) << total_charge << endl;
	cout << setw(60) << "-----------------" << endl;
	

	return 0;
}
