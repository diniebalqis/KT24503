#include <iostream>
#include <iomanip>
#include <string>
#include <cstdio>

using namespace std;

int main ()
{
	// local variables declaration
	int a,b;
	
	// name and no. matric
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 " << endl;
	
	// no. of lab and practise
	cout << " Practise 2 (Lab3)" << endl; 
	
	// results
	cout << "\n" << "\n" << endl;
	cout << " (1) Carbon Monoxide \n ";
	cout << "(2) Hydrocarbons \n ";
	cout << "(3) Nitrogen Oxides \n ";
	cout << "(4) Nonmethane Hydrocarbons \n " << endl;
	cout << "\n" << "\n" << endl;
	cout << " Enter pollutant number >> ";
	cin >> a;
	cout << " Enter odometer reading >> ";
	cin >> b;


    if (a==1 && b<=50000){
    	cout << " Emissions exceed permitted level of 3.5 grams/mile. " << endl;
	}
	else if (a==1 && b>50000){
		cout << " Emissions exceed permitted level of 4.5 grams/mile. " << endl;
	}
	if (a==2 && b<=50000){
		cout << " Emissions exceed permitted level of 0.30 grams/mile. " << endl; 
	}
	else if (a==2 && b>50000){
		cout << " Emissions exceed permitted level of 0.40 grams/mile. " << endl;
	}
	if (a==3 && b<=50000){
		cout << " Emissions exceed permitted level of 0.40 grams/mile. " << endl;
	}
	else if (a==3 && b>50000){
		cout << " Emissions exceed permitted level of 0.50 grams/mile. " << endl;
	}
	if (a==4 && b<=50000){
	    cout << " Emissions exceed permitted level of 0.25 grams/mile. " << endl;	
	}
	else if (a==4 && b>50000){
		cout << " Emissions exceed permitted level of 0.31 grams/mile. " << endl;
	}
	
	return 0;
}
