#include <iostream>
#include <cstdio>
#include <string>
#include <iomanip>

using namespace std;

int main ()
{
	double wt_lb, ht_in;
	
	// name & no. matric
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 " << endl; 
	
	// no. of lab and practise
	cout << " Practise 1 (Lab3)" << endl;
	
	// data input & output
	cout << "\n" << "\n" << endl;
	cout << " USER'S BODY MASS INDEX (BMI) CALCULATOR \n " << endl;
	
	cout << " Enter weight in pounds => ";
	cin >> wt_lb;
	
	cout << " Enter height in inches => ";
	cin >> ht_in;
	
	// BMI formulas
	double BMI = (703*wt_lb)/(ht_in*ht_in);
	cout << fixed << setprecision(2);
	
	// results
	cout << " Your BMI is " << BMI << endl; 
	
	if (BMI< 18.5)
	   cout << " and your status is underweight \n";
		
	else if(BMI>= 18.5 && BMI<= 24.9)
	   cout << " and your status is normal \n";
	   
	else if (BMI> 24.9 && BMI <= 29.9) 
	   cout << " and your status is overweight \n";
	
	else if (BMI > 29.9) 
	   cout << " and your status is obese \n";
	  
	return 0;	
}
