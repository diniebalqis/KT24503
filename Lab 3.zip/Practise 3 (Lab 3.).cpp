#include <iostream>
#include <iomanip>
#include <string>
#include <cstdio>
#include <ctime>

using namespace std;

int main()
{
    // variables
	int d,m,y;
	
	// name and no. matric
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029" << endl;
	
	// no. of lab and practise
	cout << " Practise 3 (Lab3)" << endl;
	
	// results
	cout << "\n" << "\n" << endl;
	cout << " Enter the day   (e.g : 12)            : " << endl;
	cin >>  d;
	cout << " Enter the month (e.g : 1 for January) : " << endl;
	cin >>  m;
	cout << " Enter the year  (e.g : 1993)          : " << endl;
	cin >>  y;

	
	int total_day;
	if ((y%4==0)&& (y%100==0)&& (y%400==0)||(y%4==0)&& (y%100!=0)&& (y%400!=0))
	{
		if (m==1)
	{
	total_day=(d);
	}
		else if (m==2)
	{
	total_day=(d + 29);
	}
		else if (m==3)
	{
	total_day=(d + 29 + 31);
	}
		else if (m==4)
	{
	total_day=(d + 29 + 31 + 30);
	}
		else if (m==5)
	{
	total_day=(d + 29 + 31 + 30 + 31);
	}
		else if (m==6)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30);
	}
		else if (m==7)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30 + 31);
	}
		else if (m==8)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30 + 31 + 31);
	}
		else if (m==9)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30);
	}
		else if (m==10)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31);
	}
		else if (m==11)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30);
	}
		else if (m==12)
	{
	total_day=(d + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31);
	}
	}
	
	else
	{
		if (m==1)
	{
	total_day=(d);
	}
		else if (m==2)
	{
	total_day=(d + 28);
	}
		else if (m==3)
	{
	total_day=(d + 28 + 31);
	}
		else if (m==4)
	{
	total_day=(d + 28 + 31 + 30);
	}
		else if (m==5)
	{
	total_day=(d + 28 + 31 + 30 + 31);
	}
		else if (m==6)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30);
	}
		else if (m==7)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30 + 31);
	}
		else if (m==8)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30 + 31 + 31);
	}
		else if (m==9)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30);
	}
		else if (m==10)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31);
	}
		else if (m==11)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30);
	}
		else if (m==12)
	{
	total_day=(d + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31);
	}
	}
	
	cout << "\n" << "\n" << " Total days : " << total_day;	

return 0;	
}
