#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

void printerror();
int main()
{
    // Name, matric no., lab & practise no.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	cout << " Lab 9 ( Practise 2 ) \n" << endl;

	char lines;
	string filename;
	string outfile;
	cout<<"Please enter a filename for input file: ";
	getline (cin, filename);
	cout<<"Please enter your information/statements (Enter a dot to stop)"<<endl;
	ofstream store (filename.c_str());
	if(store.is_open())
	{
		while(lines!='.')
		{
			cin.get(lines);
			store.put(lines);
		}
		store.close();
	}
	else
	{
		printerror();
	}

	ifstream copy (filename.c_str());
	cout<<"Please enter a name for output file: ";
	cin>>outfile;
	ofstream fetch (outfile.c_str());
	string takeline;

	while(getline(copy, takeline))
	{
		for(int i= takeline.length()-1; i>=0; i--)
		{
			cout<<takeline[i];
			fetch<<takeline[i];
		}
		cout<<endl;
		fetch<<endl;
	}


}

void printerror()
{
	cout<<"UNABLE TO CREATE OR OPEN FILE"<<endl;
}
