#include <iostream>

using namespace std;

class Student {

private:
	string name;
	int score;
	double total_score;
	double average_score;
	double no_of_quiz;


public:
	Student() { //constructor
		name = "n";
		score = 0;
		total_score = 0;
		average_score = 0;
		no_of_quiz = 0;
	}

	void add_quiz(int score) { //mutator
		total_score += score;
		++no_of_quiz;
	}

	double get_total_score() { //mutator
		return total_score;
	}

	double get_average_score() { //mutator
		return average_score = total_score / no_of_quiz;
	}

	void get_name() { //mutator
		cout << " What is your name? ";
		cin >> name;
	}
	string display_name() const { //accessor
		return name;
	}

};

int main()
{
    // Name & Matric No.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	// Lab & Practise No.
	cout << " Lab 10 (Practise 2) \n" << endl;

	Student std1;
	int score;

	std1.get_name();

	do {
		cout << " Please enter mark, enter -1 to stop: ";
		cin >> score;
		if (score != -1) {
			std1.add_quiz(score);

		}
		else {
			break;
		}
	} while (true);


	cout << "\n" << " Hey! " << std1.display_name() << endl;
	cout << " Your total score is : " << std1.get_total_score() << endl;
	cout << " Your average score is : " << std1.get_average_score() << endl;

	return 0;

}
