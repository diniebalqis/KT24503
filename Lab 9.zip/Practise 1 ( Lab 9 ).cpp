#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
	// Name, matric no., lab & practise no.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	cout << " Lab 9 ( Practise 1 ) \n" << endl;
	
	// Open a file with the name hello.txt.
 	ofstream out;
 	out.open("hello.txt");
	
	// Store the message "Hello, World!" in the file.
 	out << "Hello, World!";
 	
	// Close the file.
 	out.close();
 
 	// Open the same file again.
 	ifstream in;
 	in.open("hello.txt");

 	// Read the message into a string variable and print it.
 	string message;
 	getline(in, message);
 	
 	cout << message << endl;
 	
	// Close the file	
	in.close();
 	
	 return 0;
}
