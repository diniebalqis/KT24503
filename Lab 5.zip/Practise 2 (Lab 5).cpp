#include <iostream>

using namespace std;
void calculated_score(int number);
// global declaration
int sum = 0;
int smallest = 100000;
	
int main()
{
	// name & matric no.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	// lab no. & practise no.
	cout << " Lab 5 (Practise 2) \n" << endl;
	
	// variables declaration
	int a;

	do
	{
		cout << " Enter a test score (-1 to stop) : ";
		cin >> a;
		
		if (cin.fail()){
			// option 1: use break to exit the event
			cout << " Please enter INTEGER ! ";
			break;	
		}else if(a!=-1){
		calculated_score(a);
		}
	
	}while(a!=-1);
	cout << "\n" << " Lowest value  :" << smallest << endl;
	cout << " Sum of value  :" << sum << endl;
	calculated_score(a);
	return 0;
}
void calculated_score(int number)
{
	sum = sum + number;
	if (smallest > number);{
		smallest = number;
	}	
}

