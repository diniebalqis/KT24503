#include <iostream>
#include <string>
#include <sstream>

using namespace std;

int calc_sum_even(string number1);
int calc_sum_odd(string number1);
void credit_card_validation_test(int a, int b, string c);

int main()
{
	// name & matric no.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	// lab no. & practise no.
	cout << " Lab 5 (Practise 3) \n" << endl;
	
string a; // local declaration
	cout << "Enter your credit card number: ";
	cin >> a;
	credit_card_validation_test(calc_sum_even(a), calc_sum_odd(a), a); // called funtion out
	
	return 0;
}

// function-1
void credit_card_validation_test(int sum_even, int sum_odd, string qwer)
{

string number1; // local declaration

	int sum_all = sum_even + sum_odd;

	if (sum_all % 10 == 0){
		cout << qwer << " " << "is valid & can be use.";
	}
	else{
		cout << qwer << " " << "is invalid & cant be use." << endl;
	}
}

// function-2
int calc_sum_odd(string number1)
{
	string digit_2, digit_4, digit_6, digit_8, digit_10, digit_12, digit_14, digit_16;
	int sum_odd, b, d, f, h, j, l, n, p;
	
	digit_2  = number1.substr(1, 1);
	digit_4  = number1.substr(3, 1);
	digit_6  = number1.substr(5, 1);
	digit_8  = number1.substr(7, 1);
	digit_10 = number1.substr(9, 1);
	digit_12 = number1.substr(11, 1);
	digit_14 = number1.substr(13, 1);
	digit_16 = number1.substr(15, 1);
	
	istringstream(digit_2)  >> b;
	istringstream(digit_4)  >> d;
	istringstream(digit_6)  >> f;
	istringstream(digit_8)  >> h;
	istringstream(digit_10) >> j;
	istringstream(digit_12) >> l;
	istringstream(digit_14) >> n;
	istringstream(digit_16) >> p;
	
	sum_odd = b + d + f + h + j + l + n + p;
	
	return sum_odd;
}

// function-3
int calc_sum_even(string number1)
{

string digit_1, digit_3, digit_5, digit_7, digit_9, digit_11, digit_13, digit_15;
int sum_even, a, c, e, g, i, k, m, o;	

digit_1  = number1.substr(0, 1);	
digit_3  = number1.substr(2, 1);
digit_5  = number1.substr(4, 1);
digit_7  = number1.substr(6, 1);	
digit_9  = number1.substr(8, 1);
digit_11 = number1.substr(10, 1);
digit_13 = number1.substr(12, 1);
digit_15 = number1.substr(14, 1);
	

istringstream(digit_1)  >> a;
istringstream(digit_3)  >> c;
istringstream(digit_5)  >> e;
istringstream(digit_7)  >> g;
istringstream(digit_9)  >> i;
istringstream(digit_11) >> k;
istringstream(digit_13) >> m;
istringstream(digit_15) >> o;

	if (a * 2 >= 10)
	{
		a = a * 2 - 9;
	}
	else
	{ 	
		a = a * 2;	
	}			
					
	
	if (c * 2 >= 10)
	{
		c = c * 2 - 9;
	}
	else
	{ 	
		c = c * 2;	
	}							
	
								
	if (e * 2 >= 10)
	{
		e = e * 2 - 9;
	}
	else
	{ 	
		e = e * 2;	
	}														

	
	if (g * 2 >= 10)
	{
		g = g * 2 - 9;
	}
	else
	{ 	
		g = g * 2;	
	}																			
												

	if (i * 2 >= 10)
	{
		i = i * 2 - 9;
	}
	else
	{ 	
		i = i * 2;	
	}


	if (k * 2 >= 10)
	{
		k = k * 2 - 9;
	}
	else
	{ 	
		k = k * 2;	
	}

	
	if (m * 2 >= 10)
	{
		m = m * 2 - 9;
	}
	else
	{ 	
		m = m * 2;	
	}


	if (o * 2 >= 10)
	{
		o = o * 2 - 9;
	}
	else
	{ 	
		o = o * 2;	
	}
		
	sum_even = a + c  + e + g + i + k + m + o;
		
	return sum_even;
	
}
