#include <iostream>

using namespace std;
void reverse (int number);

int main()
{
	// name & matric no.
	cout << " Nur Dinie Balqis Binti Abdul Yazid \n" << " BI19110029 \n" << endl;
	// lab no. & practise no.
	cout << " Lab 5 (Practise 1) \n" << endl;
	
	// variables declaration
	int a;
	
	cout << " Enter an Integer (not exceed 5 digits)   : ";
	cin >> a;
	reverse (a);	
	return 0;
}

void reverse (int number)
{
	cout << " Reverse of Integer : ";
	cout << ((((number%10000)%1000)%100)%10);
	cout << ((((number%10000)%1000)%100)/10);
	cout << (((number%10000)%1000)/100);
	cout << ((number%10000)/1000);
	cout << (number/10000);
	
}


