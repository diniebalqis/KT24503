#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    // detail -name,matric no., lab
	cout << "\n Nur Dinie Balqis Binti Abdul Yazid\n" << " BI19110029\n" << endl;
	cout << " Lab 7 (Practise 1)\n" << endl;

    srand (time(0));
    vector <int> x;

    for (int i=0; i<10; i++)
    {
       x.push_back (rand()%100);
    }

    cout << " All elements that generated randomly in sequence: " << endl;
    for (auto i = x.begin(); i != x.end(); ++i)
    {
        cout << " " << *i << " ";
    }
    cout << endl << endl;

    cout << " The first element in random sequence: " << *x.begin();
    cout << endl << endl;

    cout << " The last element in random sequence: " << x.back();
    cout << endl << endl;

    cout << " All elements  in reverse sequence: " << endl;
    for (auto i = x.rbegin(); i != x.rend(); ++i)
    {
        cout << " " << *i << " ";
    }
    cout << endl << endl;

    cout << " Odd elements in random sequence: " << endl;
    for (auto i = x.begin(); i != x.end(); i = i + 2)
    {
        cout << " " << *i << " ";
    }
    cout << endl << endl;

    cout << " Even elements in random sequence: " << endl;
    for (auto i = x.begin() + 1; i != x.end() + 1; i = i + 2)
    {
    cout << " " << *i << " ";
    }
    cout << endl << endl;

    return 0;
}
