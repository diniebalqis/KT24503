#include <iostream>
#include <vector>

using namespace std;

int calculateTotalOdd(vector<int> n, int start);
int calculateSum(int x, int y);
void validation (int w, vector<int> n, int size);

int main()
{
    // detail -name,matric no., lab
	cout << " Nur Dinie Balqis Binti Abdul Yazid\n" << " BI19110029\n" << endl;
	cout << " Lab 7 (Practise 3)\n" << endl;

	int oddsum,evensum,totalsum;
	vector<int> bcode;
	int fill;
	cout<<" Enter 12 barcode integers separated by blanks "<<endl;

	for(int i=0;i<12;i++)
	{
		cin>>fill;
		bcode.push_back(fill);
	}
	oddsum=calculateTotalOdd(bcode, 0);
	evensum=calculateTotalOdd(bcode, 1);
	totalsum=calculateSum(oddsum, evensum);
	cout<<endl;
	cout<<" The sum of the digits in the odd-numbered positions: "<<oddsum<<endl;
	cout<<" The sum of the digits in the even-numbered positions: "<<evensum<<endl;
	cout<<" The sum of the digits in the odd-numbered and even numbered positions: "<<totalsum<<endl;
	validation(totalsum, bcode, 12);
}

int calculateTotalOdd(vector<int> n, int start)
{
	int sum=0;
	for(int i=start; i<n.size()-1; i+=2)
	{
		sum+=n[i];
	}
	return sum;
}

int calculateSum (int x, int y)
{
	int total=(3*x)+y;
	return total;
}

void validation (int w, vector<int> n, int size)
{
	int lastd=(w%10);
	int mod=10-lastd;

	cout<<" Entered barcode: "<<endl;
	for(int i=0;i<n.size();i++)
	{
		cout<<n[i];
	}
	cout<<endl;

	if(lastd==n[11]||mod==n[11])
	{
		cout<<" Result: Validated Barcode!"<<endl;
	}

	else
	{
		cout<<" Result: Invalid Barcode!"<<endl;
	}
}
