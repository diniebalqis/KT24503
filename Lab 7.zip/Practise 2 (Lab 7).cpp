#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <ctime>
using namespace std;

int main()
{
    // detail -name,matric no., lab
	cout << " Nur Dinie Balqis Binti Abdul Yazid\n" << " BI19110029\n" << endl;
	cout << " Lab 7 (Practise 2)\n" << endl;

	srand (time(0));
	vector<int> dice;
	bool check= false;

	for(int i=0; i<20; i++)
	{
		dice.push_back((rand()% 6)+1);
	}

	for(int i=0; i<20; i++)
	{

		if(check==true)
		{
		if(dice[i]!=dice[i-1])
		{
			cout<<") ";
			check=false;
		}
		}

		else if (check==false)
		{
			if(dice[i]==dice[i+1])
			{
				cout<<"( ";
				check=true;
			}

		}

		cout<<dice[i]<<" ";
	}

}

