#include <iostream>

using namespace std;



int calculateTotalOdd(int code[])
{
    int totalOdd = 0;
    for(int x=0; x<=11; x++)
        {
        if(x%2==0)
            totalOdd = totalOdd + code[x];
        }
    cout << "The sum of the digits in the odd-numbered positions: " << totalOdd << endl;
    return totalOdd;
}

int calculateTotalEven(int code[])
{
    int totalEven = 0;
    for(int x=0; x<11; x++)
        {
        if(x%2!=0)
            totalEven = totalEven + code[x];
        }
    cout << "The sum of the digits in the even-numbered positions: " << totalEven << endl;
    return totalEven;
}

int main()
{
	// detail -name,matric no., lab
	cout << " Nur Dinie Balqis Binti Abdul Yazid\n" << " BI19110029\n" << endl;
	cout << " Lab 6 (Practise 3)\n" << endl;
    int code[12],totalodd,totaleven,checkdigit,sumOddEven;
    cout << "Enter 12 integers separated by blanks or <return>S:" << endl;
    for(int x=0; x<12; x++)
        cin >> code[x];
    totalodd=calculateTotalOdd(code);
    totaleven=calculateTotalEven(code);
    sumOddEven=totalodd*3+totaleven;
    cout << "The sum of the digits in the even-numbered positions and odd-numbered positions: " << sumOddEven << endl;
    cout << "Entered barcode: ";
    for(int y=0; y<12; y++)
        cout << code[y];
    cout << endl;
    if(sumOddEven%10==0)
        checkdigit = 0;
    else
        checkdigit=10-(sumOddEven%10);
    if(checkdigit==code[11])
        cout << "Barcode validated" << endl;
    else
        cout << "Error in barcode" << endl;

return 0;
}
