#include <iostream>

using namespace std;

int main()
{
	// detail -name,matric no., lab
	cout << " Nur Dinie Balqis Binti Abdul Yazid\n" << " BI19110029\n" << endl;
	cout << " Lab 6 (Practise 1)\n" << endl;
	
	int size, current_size;
	size=50;
	
	cout << " You may enter up to 50 integers: " << endl;
	cout << " How many integers would you like to enter? : ";
	cin >> current_size;
		
	int num[50];
	cout << "\n" << "\n" << " Enter your number: ";
		
		for (int x=0;x<current_size; x++)
		{
			cin >> num[x];
		}
		current_size=current_size-1;
		cout << "\n" << "\n" << " Your number reversed are: ";
		for (int y=current_size;y>=0; y--)
		{
		cout << num[y] << " ";
		}
	
	return 0;
}
