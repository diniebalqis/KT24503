#include <iostream>

using namespace std;

// funtions prototype
void fill_array(int x[],int size);
int sum_array(int x[], int size);
int find_smallest(int x[], int size);
int return_largest(int x[],int size);
int find_compare(int y);

int main()
{
	// detail -name,matric no., lab
	cout << " Nur Dinie Balqis Binti Abdul Yazid\n" << " BI19110029\n" << endl;
	cout << " Lab 6 (Practise 2)\n" << endl;
	
	int x[10], z[10];
	int y;
	int count;
	
	fill_array(x,10);
	cout << endl;
	cout << " The sum value is: "<< sum_array(x,10) << endl;
	cout << endl;
	cout << " The smallest value is: " << find_smallest(x,10) << endl;
	cout << endl;
	cout << " The largest value is: " << return_largest(x,10) << endl;
	cout << endl;
	cout << " Values smaller than 20 are: ";
	for(int i=0; i<10; i++)
	{
		y=x[i];
		z[i]= find_compare(y);
		if (z[i]==1)
		{
			cout << x[i] << " ";
			count++;
		}
	}
	cout << endl<< endl;
	cout << " There are " << count << " numbers less than 20 " << endl;
	cout << endl;
	cout << " Your reversed numbers are: ";
	for(int i=10-1; i>=0; i--)
	{
		cout << x[i] << " ";
	}
	
	return 0;
}

int find_compare(int y)
{
	if(y<20)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int return_largest(int x[], int size)
{
	int largest=0;
	for(int i=0; i<10; i++)
	{
		if (largest<x[i])
		{
			largest=x[i];
		}
	}
	return largest;
}

int find_smallest(int x[], int size)
{
	int smallest=10000;
	for(int i=0; i<10; i++)
	{
		if (smallest>x[i])
		{
			smallest=x[i];
		}
	}
	return smallest;
}

int sum_array(int x[], int size)
{
	int sum=0;
	for (int i=0;i<10; i++)
	{
		sum=sum+x[i];
	}
	return sum;
}

void fill_array(int x[],int size)
{
	cout << " Enter 10 integers with spacebar: ";
	for (int i=0; i<10; i++)
	{
	cin >> x[i];
	}	
}
